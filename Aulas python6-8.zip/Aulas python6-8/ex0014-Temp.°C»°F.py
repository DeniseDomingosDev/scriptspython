c = float(input('Informe a temperatura em °C: '))
f = ((9*c)/5+32)
print('A temperatura de {}°C em Farenheight é de: {}°F'.format(c,f))

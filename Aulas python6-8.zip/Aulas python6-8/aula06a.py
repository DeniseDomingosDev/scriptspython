#tipos primitivos (input-ler pelo teclado('...')) e saída de dados (print-escrever na tela(''))
#tipos primitivos: int(n°inteiro), float(n°real),string/str('caractere'), booleano/bool(true/false)
n1 = int (input('Digite um um número: '))
n2 = int (input('Digite outro número: '))
s = n1 + n2
#print ('A soma de ',n1, 'e', n2, 'é: ',s)
print ('A soma de {} e {} é: {} '.format(n1,n2,s))

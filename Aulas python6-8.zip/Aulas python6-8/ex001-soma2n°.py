num1 = int (input( 'Digite um número:'))
num2 = int (input('Digite outro número:'))
soma = num1 + num2
#print ('A soma dos números', num1, 'e', num2, 'é:', soma) - Também pode ser feito assim
print ('A soma dos números {} e {} é:{}'.format(num1,num2,soma))



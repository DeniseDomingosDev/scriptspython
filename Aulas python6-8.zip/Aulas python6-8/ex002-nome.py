nome = input('Digite seu nome: ')
print('Olá {}, Seja bem-vindo(a)!'.format(nome))
#print ('Olá', nome, 'Seja bem-vindo(a)!')- Também dá pra fazer assim

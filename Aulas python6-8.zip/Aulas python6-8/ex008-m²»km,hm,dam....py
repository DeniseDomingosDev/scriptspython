m  = float(input('Digite um valor em metros: '))
km = m*0.001
hm = m*0.01
dam= m*0.1
dm = m*10
cm = m*100
mm = m*1000

print(' O valor de {} em kilômetro(s) é de: {}km,\n Em hectômetro(s) é de: {}hm, \n Em decâmetro(s) é de: {:.2f}dam,'.format(m, km,hm,dam))
print(' Em decímetro(s) é de: {}dm, \n Em centímetro(s) é de: {:.0f}cm, \n Em milímetro(s) é de: {:.0f}mm'.format(dm,cm,mm))
#ou(n*100), (n*1000)
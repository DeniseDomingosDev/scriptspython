r= float(input('Digite um valor em Reais (R$): '))
d = r/5.88
print('Com R$ {:.2f}, é possível comprar: US$ {:.2f}'.format(r,d))

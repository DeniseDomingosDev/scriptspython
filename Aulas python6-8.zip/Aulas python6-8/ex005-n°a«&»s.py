n = int(input('Digite um número: '))
su = n-1
s = n+1
print('O antecessor de {} é: {} , e o sucessor é: {}'.format(n, su,s))
#print('O antecessor de {} é: {} , e o sucessor é: {}'.format(n,(n-1),(n+1)))-também pode ser feito desta forma
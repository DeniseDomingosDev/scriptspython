n= float(input('Digite o valor do produto em Reais (R$): '))
np = n-(n*5/100)
print('O valor do produto era de: R$ {:.2f} '.format(n))
print('O valor do produto com desconto de 5% é de : R$ {:.2f} '.format(np))
n = int(input('Digite um número: '))
d = n*2
t = n*3
q = n**(1/2)
print('O dobro do valor de {} é: {}.'.format(n, (n*2)))
print('O triplo de {} é {}.\nA raiz quadrada {} é {:.2f}'.format(n,(n*3), n, pow(n,(1/2))))
#também pode usar o n**(1/2))
#print('O dobro...{} {} {} {:.2f}'.format(n,d,t,q))-também pode ser feito desta forma

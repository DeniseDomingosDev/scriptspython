n1 = float(input('Digite a largura da parede em metros: '))
n2 = float(input('Digite a altura da parede em metros: '))
n3 = n1*n2
n4 = n3/2
print('As dimensões da parede são {} x {} e a área total da parede é de: {}m²'.format(n1,n2,n3))
print('A quantidade de tinta necessária para pintar a parede é de: {:.1f}'.format(n4),'Lt(s) de tinta')
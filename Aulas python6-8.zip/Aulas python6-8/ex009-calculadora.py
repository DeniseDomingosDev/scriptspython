a = int(input('Digite um número para saber a tabuada: '))
print('--'*8)
n = a*1
n1= a*2
n2= a*3
n3= a*4
n4= a*5
n5= a*6
n6= a*7
n7= a*8
n8= a*9
n9= a*10
print('A tabuada de {} é: \n 3 X 1 = {}\n 3 X 2 = {} \n 3 X 3 = {} \n 3 X 4 = {} \n 3 X 5 = {}'.format(a,n,n1,n2,n3,n4))
print(' 3 X 6 = {} \n 3 X 7 = {}\n 3 X 8 = {}\n 3 X 9 = {}\n 3 X 10 = {}'.format(n5,n6,n7,n8,n9))
#print('{} X {:2} = {}'.format(num, 1, num*1)) - Também pode ser feito desta forma
#print('{} X {:2} = {}'.format(num, 2, num*2)) - Ao invés de colocar vários n (variáveis)
#print('{} X {:2} = {}'.format(num, 3, num*3)) - E assim por diante - o ':2' é para alinhar a tabuada
print('--'*8)
import emoji
print(emoji("Hello World :sunglasses: ", use_aliases=True))
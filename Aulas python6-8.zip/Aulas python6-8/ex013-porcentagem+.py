n= float(input('Digite o valor do seu salário em Reais(R$): '))
n1= n+(n*15/100)
print('O seu salário era de: R$ {:.2f}. Com 15% de aumento, passa a ser: R$ {:.2f}'.format(n,n1))
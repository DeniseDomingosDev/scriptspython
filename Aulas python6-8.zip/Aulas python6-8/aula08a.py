#utilizando módulos (import e from)
#(import - importa todas as funcionalidades da biblioteca, e from-importa somente as funcionalidades selecionadas)
#import math: ceil(arredondamento para cima), floor(arredondamento para baixo),
#import math: trunc(truncate-eliminar o número da vírgula pra frente sem nenhum arredondamento)
#import math: pow(power(potência)-Funciona de forma semelhante a **
#import math: sqrt(square root(para calcular raiz quadrada))
#import math: factorial(para calculo de fatorial)
#como fazer as importações = from math import ceil,floor,trunc,pow,sqrt,factorial